﻿
using CustAPI.Model.CusomerModel;
using Microsoft.EntityFrameworkCore;

namespace CustAPI.Context
{
    public class CustDBContext : DbContext
    {
        public DbSet<Customer> customer { get; set; }
        public CustDBContext(DbContextOptions options) : base(options)
        { }

       
    }
}


