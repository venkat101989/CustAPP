﻿using CustAPI.Model.CusomerModel;
using CustAPI.Repository.Customer.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CustAPI.Controllers
{
    [Route("api/customer/[action]/{id?}")]
    [ApiController]
    [Authorize]
    public class CustomerController : ControllerBase
    {
        //http://localhost:5251/api/customer/AddNewCustomer
        private ICustomerRepository customerRepository { get; set; }
        public CustomerController(ICustomerRepository _customerRepository)
        {
            this.customerRepository = _customerRepository;
        }

        //[Route("AddNewUser")]
        [HttpPost(Name = "AddNewCustomer")]
        public IActionResult AddNewCustomer([FromBody]Customer customer)
        {
            var i = Convert.ToInt32(customerRepository.AddCustomer(customer));
            if (i > 0)
            {
                return Ok("Successfully Saved!!!");
            }
            return Ok("Save Error");
        }

        
        [HttpGet(Name = "GetAllCustomer")]
        public IActionResult GetAllCustomer()
        {
            var customers = customerRepository.GetAllCustomer();
            return Ok(customers);

        }

       
        [HttpGet(Name = "GetCustomerById")]
        public IActionResult GetCustomerById(int id)
        {
            var customer = customerRepository.GetCustomerById(id);
            return Ok(customer);

        }

        [HttpPut(Name = "UpdateCustomer")]
        public IActionResult UpdateCustomer([FromBody]Customer customer)
        {
            var _customer = customerRepository.UpdateCustomer(customer);
            return Ok(_customer);

        }


        [HttpDelete(Name = "DeleteCustomer")]
        public IActionResult DeleteCustomer(int id)
        {
            var cust = customerRepository.DeleteCustomer(id);

            return Ok("Deleted Successfully");

        }



    }
}
