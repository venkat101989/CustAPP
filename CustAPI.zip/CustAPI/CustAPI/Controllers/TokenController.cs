﻿using CustAPI.Model.CusomerModel;
using CustAPI.Repository.Customer.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace CustAPI.Controllers
{
    [Route("api/Token/[action]")]
    [ApiController]
    public class TokenController : ControllerBase
    {
        private readonly IConfiguration _config;
        private readonly ICustomerRepository customerRepository;
        public TokenController(IConfiguration config, ICustomerRepository _customerRepository)
        {
            this._config = config;
            this.customerRepository = _customerRepository;
        }

        [HttpGet]
        [AllowAnonymous]
        // To generate token
        public IActionResult GetToken([FromQuery] string username, string password)
        {
            var key = _config["Jwt:Key"];
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            if (!ValidateCustomer(username, password))
            {
                return Ok(null);
            }
            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier,username),
                new Claim(ClaimTypes.Role, "admin")
            };
            var token = new JwtSecurityToken(_config["Jwt:Issuer"],
                _config["Jwt:Audience"],
                claims,
                expires: DateTime.Now.AddDays(2),
                signingCredentials: credentials);


            return Ok(new JwtSecurityTokenHandler().WriteToken(token));

        }

        private bool ValidateCustomer(string username, string password)
        {
            Customer customers = customerRepository.ValidateCustomer(username, password);

            if (customers != null)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
    }
}
