﻿using CustAPI.Context;
using CustAPI.Repository.Customer.Interface;
using CustAPI.Model.CusomerModel;

namespace CustAPI.Repository.Customer.Implrepo
{
    public class CustomerRepositoryImpl : ICustomerRepository
    {
        private CustDBContext Context { get; set; }

        public CustomerRepositoryImpl(CustDBContext _context)
        {
            this.Context = _context;
        }
        public string AddCustomer(CustAPI.Model.CusomerModel.Customer customer)
        {
            Context.customer.Add(customer);
            var isinterted = Context.SaveChanges();
            return isinterted.ToString();
        }

        public string DeleteCustomer(int id)
        {
            CustAPI.Model.CusomerModel.Customer cust = Context.customer.Where(x => x.id == Convert.ToInt32(id)).ToList().First();
            Context.customer.Remove(cust);
            var isDeleted = Context.SaveChanges();
            return isDeleted.ToString();
        }

        public IEnumerable<CustAPI.Model.CusomerModel.Customer> GetAllCustomer()
        {
            return Context.customer;
        }

        public CustAPI.Model.CusomerModel.Customer GetCustomerById(int id)
        {
            CustAPI.Model.CusomerModel.Customer? customer = Context.customer.Where(x => x.id == id).ToList().FirstOrDefault();

            return customer;
        }

        public string UpdateCustomer(CustAPI.Model.CusomerModel.Customer customer)
        {
            var editedcustomer = Context.customer.Where(x => x.id == customer.id).FirstOrDefault();
            editedcustomer.firstName = customer.firstName;
            editedcustomer.lastName = customer.lastName;
            editedcustomer.email = customer.email;
            editedcustomer.address = customer.address;
            editedcustomer.phoneNumber = customer.phoneNumber;
            editedcustomer.country = customer.country;
            editedcustomer.city = customer.city;
            editedcustomer.state = customer.state;
            editedcustomer.postalCode = customer.postalCode;
            editedcustomer.password = "xxxxx";

            Context.Entry(editedcustomer).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            Context.customer.Update(editedcustomer);
            var isupdated = Context.SaveChanges();
            return isupdated.ToString();
        }

        public CustAPI.Model.CusomerModel.Customer ValidateCustomer(string username, string password)
        {
            var cust = Context.customer.Where(x => x.firstName == username && x.password == password).FirstOrDefault();
            return cust;
        }
    }
}
