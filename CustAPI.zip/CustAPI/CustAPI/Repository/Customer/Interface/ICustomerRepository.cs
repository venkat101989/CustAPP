﻿using CustAPI.Model.CusomerModel;
namespace CustAPI.Repository.Customer.Interface
{
    public interface ICustomerRepository
    {

        IEnumerable<CustAPI.Model.CusomerModel.Customer> GetAllCustomer();
        CustAPI.Model.CusomerModel.Customer GetCustomerById(int id);
        string AddCustomer(CustAPI.Model.CusomerModel.Customer customer);
        string UpdateCustomer(CustAPI.Model.CusomerModel.Customer customer);
        string DeleteCustomer(int id);

        CustAPI.Model.CusomerModel.Customer ValidateCustomer(string username, string password);
    }
}
