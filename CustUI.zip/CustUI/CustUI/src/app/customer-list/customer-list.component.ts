import { Component, OnInit } from '@angular/core';
import { customerDetails } from '../models/customerdetails'
import { CustomerService } from '../services/customerservice.service';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit{

   public customerList : customerDetails[] = new Array<customerDetails>();

   constructor(private customerService: CustomerService){
    var customer = new customerDetails();
    customer.id = "1";
    customer.firstName = "test";
    customer.lastName = "lastname";
    customer.email = "testemail@email.com";
    customer.phoneNumber = "6565656565";
    customer.address = "chennai";
    customer.city = "chennai";
    customer.country = "india";
    customer.state = "TN";
    customer.postalCode = "605555";
    this.customerList.push(customer);
    customer = new customerDetails();
    customer.id = "2";
    customer.firstName = "test2";
    customer.lastName = "lastname22";
    customer.email = "testemail2@email.com";
    customer.phoneNumber = "62565656565";
    customer.address = "chennai2";
    customer.city = "chennai2";
    customer.country = "india";
    customer.state = "TN";
    customer.postalCode = "605555";
    this.customerList.push(customer);

    this.getToken();


   }

   ngOnInit()
   {
    this.customerList = [];
    this.GetAllCustomer();
   }

   getToken()
   {
    this.customerService.GetToken('venkat','xxxxx').subscribe((data)=> {
        localStorage.setItem('custToken', data);
     });
   }

   GetAllCustomer()
   {
       this.customerService.GetAllCustomer().subscribe((data)=> {
             this.customerList = data;
       });
   }

   DeleteCustomer(id:any)
   {
      this.customerService.DeleteCustomer(id).subscribe((data)=> {
        this.ngOnInit();
       });
   }

}
