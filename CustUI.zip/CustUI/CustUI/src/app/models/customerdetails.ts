export class customerDetails {
    public id : string = "";
    public firstName: string = "";
    public lastName: string = "";
    public email: string = "";
    public phoneNumber: string = "";
    public address: string = "";
    public city: string = "";
    public state: string = "";
    public country: string = "";
    public postalCode: string = "";
    public password: string = "";
}