import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  private apiUrl = 'http://localhost:5251/api'; // Replace with API endpoint
  private token = "";

  constructor(private http: HttpClient) {
    var tokens = localStorage.getItem("custToken");
    if(tokens != null)
    {
      this.token = tokens;
    }
    
  }
 
  GetToken(user :string, password :string): Observable<any>
  {
    const url = `${this.apiUrl}/token/gettoken?username=${user}&password=${password}`;
    const headers = new HttpHeaders({
      'Content-Type': 'application/text',
      // Add any additional headers as needed
    });
    // Perform the GET request
    return this.http.get(url, { headers,responseType:'text' });
  }

  // Method to perform HTTP POST request
   AddCustomer(data: any): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${this.token}`,
      // Add any additional headers as needed
    });

     
    // You can customize the API endpoint accordingly
    const url = `${this.apiUrl}/customer/AddNewCustomer`;

    // Perform the POST request
    return this.http.post(url, data, { headers,responseType:'text' });
  }

  GetAllCustomer(): Observable<any> {
    //alert(this.token);
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${this.token}`,
      // Add any additional headers as needed
    });
    const url = `${this.apiUrl}/customer/GetAllCustomer`;

    // Perform the GET request
    return this.http.get(url, {headers});
  }

  GetCustomerById(id:any): Observable<any> {
    //alert(id)
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${this.token}`,
      // Add any additional headers as needed
    });
    const url = `${this.apiUrl}/customer/GetCustomerById/`+ id;
    console.log(url);
    // Perform the GET request
    return this.http.get(url, {headers});
  }


  // Method to perform HTTP POST request
  UpdateCustomer(data: any): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${this.token}`,
      // Add any additional headers as needed
    });

     
    // You can customize the API endpoint accordingly
    const url = `${this.apiUrl}/customer/UpdateCustomer`;

    // Perform the POST request
    return this.http.put(url, data, { headers,responseType:'text' });
  }

  DeleteCustomer(id:any): Observable<any> {
    //alert(id)
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${this.token}`,
      // Add any additional headers as needed
    });
    const url = `${this.apiUrl}/customer/DeleteCustomer/`+ id;
    console.log(url);
    // Perform the GET request
    return this.http.delete(url, {headers,responseType:'text'});
  }

}
