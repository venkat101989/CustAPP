import { Component, OnInit, ViewChild } from '@angular/core';
import { customerDetails } from '../models/customerdetails'
import { FormControl,NgForm, FormGroup,NgModel,FormsModule} from '@angular/forms';
import { CustomerService } from '../services/customerservice.service'
import { ActivatedRoute, Route, Router } from '@angular/router';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  private customerDetails:customerDetails = new customerDetails();
  constructor(
    private customerService:CustomerService,
    private route: ActivatedRoute,
    private router : Router )
  {
     this.customerDetails = new customerDetails();
  } 



@ViewChild('customerForm') myform: any;

ngOnInit(): void {
 
  const id = this.route.snapshot.params['id'];

  if(typeof id !== 'undefined')
  {
    //alert(id);

    setTimeout(() => { 
      this.EditCustomer(id);
    });
  }
  
}

EditCustomer(id:string)
{
// var model = {firstName : "sdsd", lastName:  "", email : "", phoneNumber: ""};
    //var customerEditedforms = this.myform
    //customerEditedforms.value.firstName = "";
    //console.log(customerEditedforms.value);

   this.customerService.GetCustomerById(id).subscribe((data)=> {
    this.customerDetails = new customerDetails();
   // this.customerDetails.firstName = data.firstName;
    //this.customerDetails.lastName = data.lastName;
    console.log('edit data');
     console.log(data);

    this.customerDetails= data;
    this.myform.setValue(this.customerDetails);

   })

    this.customerDetails = this.myform.value;
    this.customerDetails.firstName = "";
    this.myform.setValue(this.customerDetails);
}

SaveCustomer(form:any)
{
   this.customerDetails = form.value;
   //console.log(form.value);
   console.log(this.customerDetails);

   if(this.customerDetails.id != '' && this.customerDetails.id != null )
   {
    //alert('update');

    this.customerService.UpdateCustomer(this.customerDetails).subscribe((data)=>
    {
      console.log(data);
     this.router.navigate(['']);
    });
   }else{
    //alert('insert');
    this.customerDetails.id = "0";
    this.customerDetails.password = "xxxxx";
    this.customerService.AddCustomer(this.customerDetails).subscribe((data)=>
    {
      console.log(data);
     this.router.navigate(['']);
    });

   }



   
}

}
