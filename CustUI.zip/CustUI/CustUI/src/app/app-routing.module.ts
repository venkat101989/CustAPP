import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomerListComponent } from '../app/customer-list/customer-list.component'
import { CustomerComponent } from '../app/customer/customer.component'

const routes: Routes = [ 
  {path: '', component: CustomerListComponent},
  {path: 'AddCustomer', component: CustomerComponent},
  {path: 'AddCustomer/:id', component: CustomerComponent},
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
